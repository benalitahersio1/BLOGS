# frozen_string_literal: true
class Gem::Commands::CrashCommand < Gem::Command

  raise "crash"

end
